
 
<?php $__env->startSection('title', 'Add New Car'); ?>
 
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('car.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label>Merk</label>
        <select name="merk_id" class="form-control">
            <?php $__currentLoopData = $merks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($merk->id); ?>"><?php echo e($merk->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <label>Model</label>
        <input type="text" name="model" class="form-control">
    </div>
    <div class="mb-3">
        <label>Color</label>
        <input type="text" name="color" class="form-control">
    </div>
    <div class="mb-3">
        <label>Year</label>
        <input type="number" name="year" class="form-control">
    </div>
    <div class="mb-3">
        <label>Price</label>
        <input type="number" name="price" class="form-control">
    </div>
    <div class="mb-3">
        <label>Image</label>
        <input type="file" name="image" class="form-control">
    </div>
    <button class="btn btn-primary" type="submit">Save</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car_laravel\resources\views/car/create.blade.php ENDPATH**/ ?>