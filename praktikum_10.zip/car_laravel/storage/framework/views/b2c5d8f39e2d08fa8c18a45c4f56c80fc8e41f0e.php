

<?php $__env->startSection('title', 'Car List'); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('car.create')); ?>" class="btn btn-primary mb-3">Add New Car</a>

    <?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Merk</th>
                <th>Model</th>
                <th>Color</th>
                <th>Year</th>
                <th>Price</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($car->id); ?></td>
                    <td><?php echo e($car->merk->name); ?></td>
                    <td><?php echo e($car->model); ?></td>
                    <td><?php echo e($car->color); ?></td>
                    <td><?php echo e($car->year); ?></td>
                    <td>Rp <?php echo e(number_format($car->price, 0, ',', '.')); ?></td>
                    <td>
                        <img src="<?php echo e(asset('storage/' . $car->image)); ?>" width="100" alt="Car Image">
                    </td>
                    <td>
                        <a href="<?php echo e(route('car.show', $car->id)); ?>" class="btn btn-info btn-sm">View</a>
                        <a href="<?php echo e(route('car.edit', $car->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                        <form action="<?php echo e(route('car.destroy', $car->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\car_laravel\resources\views/car/index.blade.php ENDPATH**/ ?>