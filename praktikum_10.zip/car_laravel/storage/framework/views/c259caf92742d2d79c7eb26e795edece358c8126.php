<!DOCTYPE html>
<html>
<head>
    <title>Laravel</title>
</head>
<body>
    <h1>Welcome</h1>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\car_laravel\resources\views/welcome.blade.php ENDPATH**/ ?>